# AD430-Seattle-Emergency-Hubs

This is the description from the customer (will update by next week):

This is the website where folks can find the Emergency Communication Hubs.  The map is interactive.  

http://seattleemergencyhubs.org/seattle-emergency-neighborlink-map/
Seattle Emergency NeighborLink Map | Seattle Emergency Hubs | Seattle, WA
Make your mark on preparedness Add yourself to the Seattle Emergency NeighborLink map!! If you are a current or new SNAP Coordinator, Block Watch Captain, Hub Captain or CERT Member, and want to know who else has organized their neighbors for safety or disaster, this is your opportunity to connect with others BEFORE a happens.
seattleemergencyhubs.org
Hubs are just meeting spots where neighbors will naturally gather to help one another post-disaster.  Some of them have volunteers who have gotten organized and prepositioned supplies to help neighbors exchange information.  Of the sites that are organized, many of them have a box that looks like the attached photo.


We anticipate the internet and all cell phone signal to be down after a big earthquake so folks need to use the app and identify (and store) the Hub closest to home and work before anything happens.  
